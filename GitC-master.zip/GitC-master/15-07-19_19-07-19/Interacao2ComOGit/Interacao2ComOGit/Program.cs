﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interacao2ComOGit
{
    class Program
    {
        static void Main(string[] args)
        {
            //Segundo projeto de interaçao com o github.
            Console.WriteLine("Agora ja sei usar o basico do gitHub.");
        }
    }
}
