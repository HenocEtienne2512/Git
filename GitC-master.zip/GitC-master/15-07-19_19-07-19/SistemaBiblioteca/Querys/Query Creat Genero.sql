﻿CREATE TABLE [dbo].[Generos]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	[Tipo] varchar(200) NOT NULL,
	[Descricao] varchar(1000) null
)
